# Learn STEM with Silas — Web App

A deploy-ready version of the Learn STEM with Silas AI STEM tutor.

## What it includes
- Mathematics, Physics, Chemistry, Biology and Computer Science
- Solve step-by-step
- Hint mode
- Teach Me mode
- Practice mode
- Silas's Experience section using only the supplied real experience
- Accuracy rule: use accepted laws, principles and theoretically accurate formulas
- Responsive mobile-friendly interface
- Secure server-side OpenAI API key
- Health endpoint at `/api/health`

## Run locally

1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Put your OpenAI API key in `.env`.
6. Set `OPENAI_MODEL` to a model available to your OpenAI API account.
7. Run `npm start`.
8. Open `http://localhost:3000`.

Never put your API key inside `index.html`.

## Put it online

The included `render.yaml` is ready for Render.

1. Create a GitHub repository.
2. Upload these project files.
3. Create a new Web Service on Render and connect the repository.
4. Render will use the included build/start settings.
5. Add `OPENAI_API_KEY` and `OPENAI_MODEL` as environment variables.
6. Deploy.
7. Render will give you a public HTTPS address.

## Important

The browser talks to `/api/solve`, `/api/hint`, `/api/teach`, and `/api/practice`. The API key stays on the server.

